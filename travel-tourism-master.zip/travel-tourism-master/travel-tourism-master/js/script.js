$(".shadowHover").mouseenter(function() {
    $(this).addClass("shado");
});
$(".shadowHover").mouseleave(function() {
    $(this).removeClass("shado");
});